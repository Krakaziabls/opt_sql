package com.example.backend.config;

import org.springframework.boot.test.context.TestConfiguration;

@TestConfiguration
public class TestJwtConfig {
    // JWT configuration is now in TestSecurityConfig
} 