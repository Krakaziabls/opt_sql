package com.example.backend.config;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReentrantLock;

import org.springframework.stereotype.Component;
import org.springframework.web.socket.WebSocketSession;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class WebSocketSessionManager {
    
    private final Map<String, WebSocketSession> userSessions = new ConcurrentHashMap<>();
    private final Map<String, ReentrantLock> sessionLocks = new ConcurrentHashMap<>();
    
    public void addSession(String username, WebSocketSession session) {
        ReentrantLock lock = sessionLocks.computeIfAbsent(username, k -> new ReentrantLock());
        
        try {
            lock.lock();
            WebSocketSession existingSession = userSessions.get(username);
            
            if (existingSession != null && existingSession.isOpen()) {
                log.info("Closing existing session for user: {}", username);
                try {
                    existingSession.close();
                } catch (Exception e) {
                    log.error("Error closing existing session for user: {}", username, e);
                }
            }
            
            // Даем небольшую задержку для гарантированного закрытия старой сессии
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            
            userSessions.put(username, session);
            log.info("Added new session for user: {}", username);
        } finally {
            lock.unlock();
        }
    }
    
    public void removeSession(String username) {
        ReentrantLock lock = sessionLocks.computeIfAbsent(username, k -> new ReentrantLock());
        
        try {
            lock.lock();
            WebSocketSession session = userSessions.remove(username);
            if (session != null && session.isOpen()) {
                try {
                    session.close();
                } catch (Exception e) {
                    log.error("Error closing session for user: {}", username, e);
                }
            }
            log.info("Removed session for user: {}", username);
        } finally {
            lock.unlock();
        }
    }
    
    public WebSocketSession getSession(String username) {
        return userSessions.get(username);
    }
    
    public boolean hasActiveSession(String username) {
        WebSocketSession session = userSessions.get(username);
        return session != null && session.isOpen();
    }
} 