package com.example.backend.service;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.backend.exception.ApiException;
import com.example.backend.exception.ResourceNotFoundException;
import com.example.backend.model.dto.MessageDto;
import com.example.backend.model.dto.SqlQueryRequest;
import com.example.backend.model.dto.SqlQueryResponse;
import com.example.backend.model.entity.Chat;
import com.example.backend.model.entity.DatabaseConnection;
import com.example.backend.model.entity.Message;
import com.example.backend.model.entity.SqlQuery;
import com.example.backend.repository.ChatRepository;
import com.example.backend.repository.DatabaseConnectionRepository;
import com.example.backend.repository.MessageRepository;
import com.example.backend.repository.SqlQueryRepository;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Service
@RequiredArgsConstructor
@Slf4j
public class SqlOptimizationOrchestrator {
    private final ChatRepository chatRepository;
    private final DatabaseConnectionRepository databaseConnectionRepository;
    private final MessageRepository messageRepository;
    private final SqlQueryRepository sqlQueryRepository;
    private final LLMService llmService;
    private final DatabaseConnectionService databaseConnectionService;
    private final ChatService chatService;

    @Transactional
    public Mono<SqlQueryResponse> optimizeQuery(Long userId, SqlQueryRequest request) {
        log.info("Starting query optimization orchestration for userId={}, chatId={}, query={}, llm={}",
                userId, request.getChatId(), request.getQuery(), request.getLlm());

        return validateRequest(userId, request)
                .flatMap(chat -> processDatabaseConnection(request))
                .flatMap(dbConnection -> optimizeQueryWithLLM(request))
                .flatMap(optimizedQuery -> saveOptimizationResult(userId, request, optimizedQuery))
                .onErrorMap(this::handleError);
    }

    private Mono<Chat> validateRequest(Long userId, SqlQueryRequest request) {
        return Mono.fromCallable(() -> {
            Chat chat = chatRepository.findById(request.getChatId())
                    .orElseThrow(() -> new ResourceNotFoundException("Chat not found with ID: " + request.getChatId()));
            
            // Здесь можно добавить дополнительные проверки прав доступа
            return chat;
        });
    }

    private Mono<DatabaseConnection> processDatabaseConnection(SqlQueryRequest request) {
        if (request.getDatabaseConnectionId() == null || request.getDatabaseConnectionId().isBlank()) {
            return Mono.empty();
        }

        return Mono.fromCallable(() -> {
            try {
                Long dbConnectionId = Long.parseLong(request.getDatabaseConnectionId());
                return databaseConnectionRepository.findByIdAndChatId(dbConnectionId, request.getChatId())
                        .orElseThrow(() -> new ResourceNotFoundException(
                                "Database connection not found or not linked to chat: " + dbConnectionId));
            } catch (NumberFormatException e) {
                throw new ApiException("Invalid database connection ID: " + request.getDatabaseConnectionId(),
                        HttpStatus.BAD_REQUEST);
            }
        });
    }

    private Mono<String> optimizeQueryWithLLM(SqlQueryRequest request) {
        return llmService.optimizeSqlQuery(request.getQuery(), request.getLlm())
                .doOnSuccess(optimizedQuery -> log.debug("LLM optimization successful: {}", optimizedQuery))
                .doOnError(error -> log.error("LLM optimization failed: {}", error.getMessage(), error));
    }

    private Mono<SqlQueryResponse> saveOptimizationResult(Long userId, SqlQueryRequest request, String optimizedQuery) {
        return Mono.fromCallable(() -> {
            // Сохраняем сообщение пользователя
            MessageDto userMessageDto = MessageDto.builder()
                    .content(request.getQuery())
                    .fromUser(true)
                    .build();
            MessageDto savedUserMessageDto = chatService.sendMessage(request.getChatId(), userId, userMessageDto);
            
            // Получаем сущность Message из репозитория
            Message savedUserMessage = messageRepository.findById(savedUserMessageDto.getId())
                    .orElseThrow(() -> new ResourceNotFoundException("User message not found: " + savedUserMessageDto.getId()));

            // Сохраняем ответ LLM
            MessageDto llmMessageDto = MessageDto.builder()
                    .content(optimizedQuery)
                    .fromUser(false)
                    .build();
            MessageDto savedLlmMessageDto = chatService.sendMessage(request.getChatId(), userId, llmMessageDto);

            // Получаем сущность Message для ответа LLM
            Message savedLlmMessage = messageRepository.findById(savedLlmMessageDto.getId())
                    .orElseThrow(() -> new ResourceNotFoundException("LLM message not found: " + savedLlmMessageDto.getId()));

            // Создаем и сохраняем SQL-запрос
            SqlQuery sqlQuery = SqlQuery.builder()
                    .message(savedUserMessage)
                    .originalQuery(request.getQuery())
                    .optimizedQuery(optimizedQuery)
                    .createdAt(LocalDateTime.now())
                    .build();

            SqlQuery savedQuery = sqlQueryRepository.save(sqlQuery);

            return SqlQueryResponse.builder()
                    .id(savedQuery.getId())
                    .originalQuery(savedQuery.getOriginalQuery())
                    .optimizedQuery(savedQuery.getOptimizedQuery())
                    .createdAt(savedQuery.getCreatedAt())
                    .message(savedLlmMessageDto)
                    .build();
        });
    }

    private Throwable handleError(Throwable error) {
        if (error instanceof ResourceNotFoundException || error instanceof ApiException) {
            return error;
        }
        log.error("Unexpected error during query optimization: {}", error.getMessage(), error);
        return new ApiException("Internal error during query optimization", HttpStatus.INTERNAL_SERVER_ERROR);
    }
} 