import React, { useState, useEffect, useCallback, memo, useMemo } from 'react';
import { Client, StompSubscription } from '@stomp/stompjs';
import SockJS from 'sockjs-client';
import { Button } from './Button';
import { Input } from './Input';
import { cn } from '../lib/utils';
import LLMSelect from './LLMSelect';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism';
import { Message } from '../api/chat';
import { sqlApi } from '../api/sql';
import { connectionApi, DatabaseConnectionDto } from '../api/connection';
import { chatApi } from '../api/chat';

interface ChatAreaProps {
    selectedChatId: string;
    selectedLLM: string;
    onSelectLLM: (llm: string) => void;
    onConnectDB: () => void;
}

interface WebSocketClient extends Client {
    subscription?: StompSubscription;
}

const ChatArea: React.FC<ChatAreaProps> = memo(({
                                                    selectedChatId,
                                                    selectedLLM,
                                                    onSelectLLM,
                                                    onConnectDB,
                                                }) => {
    const [message, setMessage] = useState('');
    const [mppToggle, setMppToggle] = useState(false);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const [connections, setConnections] = useState<DatabaseConnectionDto[]>([]);
    const [localMessages, setLocalMessages] = useState<Message[]>([]);
    const processedMessageIds = React.useRef<Set<string>>(new Set());
    const wsClient = React.useRef<WebSocketClient | null>(null);
    const isConnectingRef = React.useRef(false);
    const messagesEndRef = React.useRef<HTMLDivElement>(null);
    const reconnectTimeoutRef = React.useRef<NodeJS.Timeout | null>(null);
    const messageQueueRef = React.useRef<Set<string>>(new Set());
    const subscriptionRef = React.useRef<StompSubscription | null>(null);

    const isSQLQuery = useCallback((text: string) => {
        const upperText = text.toUpperCase();
        return upperText.includes('SELECT') && upperText.includes('FROM');
    }, []);

    const scrollToBottom = useCallback(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }, []);

    useEffect(() => {
        scrollToBottom();
    }, [localMessages, scrollToBottom]);

    // Закрытие WebSocket при обновлении страницы
    useEffect(() => {
        const handleBeforeUnload = () => {
            if (wsClient.current?.active) {
                wsClient.current.deactivate(); // Закрываем WebSocket
            }
        };

        window.addEventListener('beforeunload', handleBeforeUnload);

        return () => {
            window.removeEventListener('beforeunload', handleBeforeUnload);
        };
    }, []);

    const processMessage = useCallback((message: Message) => {
        if (processedMessageIds.current.has(message.id)) {
            console.log('Duplicate message received, skipping:', message.id);
            return;
        }

        if (messageQueueRef.current.has(message.id)) {
            console.log('Message already in queue, skipping:', message.id);
            return;
        }

        messageQueueRef.current.add(message.id);
        processedMessageIds.current.add(message.id);

        setLocalMessages(prev => {
            const exists = prev.some(m => m.id === message.id);
            if (exists) {
                messageQueueRef.current.delete(message.id);
                return prev;
            }
            const newMessages = [...prev, message];
            messageQueueRef.current.delete(message.id);
            return newMessages;
        });
    }, []);

    const cleanupWebSocket = useCallback(async () => {
        if (reconnectTimeoutRef.current) {
            clearTimeout(reconnectTimeoutRef.current);
            reconnectTimeoutRef.current = null;
        }
        
        if (subscriptionRef.current) {
            try {
                subscriptionRef.current.unsubscribe();
                subscriptionRef.current = null;
            } catch (error) {
                console.error('Error unsubscribing:', error);
            }
        }
        
        if (wsClient.current?.active) {
            try {
                await wsClient.current.deactivate();
            } catch (error) {
                console.error('Error during WebSocket cleanup:', error);
            }
            wsClient.current = null;
        }
    }, []);

    // WebSocket с улучшенной логикой повторного подключения и проверкой на дубликаты
    useEffect(() => {
        if (!selectedChatId) return;

        let reconnectAttempts = 0;
        const maxReconnectAttempts = 5;
        const baseReconnectDelay = 5000;

        const connectWebSocket = async () => {
            if (isConnectingRef.current || wsClient.current?.active) {
                console.log('WebSocket connection already in progress or active');
                return;
            }

            isConnectingRef.current = true;
            const token = localStorage.getItem('token');
            if (!token) {
                console.error('No token found');
                isConnectingRef.current = false;
                return;
            }

            try {
                await cleanupWebSocket();

                const socket = new SockJS('http://localhost:8080/api/ws', null, { 
                    transports: ['websocket'], 
                    timeout: 5000 
                });

                const client = new Client({
                    webSocketFactory: () => socket,
                    reconnectDelay: baseReconnectDelay,
                    heartbeatIncoming: 25000,
                    heartbeatOutgoing: 25000,
                    connectHeaders: { 'Authorization': `Bearer ${token}` },
                    debug: (str) => console.log('STOMP Debug:', str),
                    onStompError: (error) => {
                        console.error('STOMP error:', error);
                        isConnectingRef.current = false;
                        scheduleReconnect();
                    },
                    onWebSocketError: (event) => {
                        console.error('WebSocket error:', event);
                        isConnectingRef.current = false;
                        scheduleReconnect();
                    },
                    onConnect: () => {
                        console.log('WebSocket connected successfully');
                        isConnectingRef.current = false;
                        reconnectAttempts = 0;

                        const topic = `/topic/chat/${selectedChatId}`;
                        if (subscriptionRef.current) {
                            subscriptionRef.current.unsubscribe();
                        }
                        subscriptionRef.current = client.subscribe(topic, (message) => {
                            try {
                                const newMessage: Message = JSON.parse(message.body);
                                processMessage(newMessage);
                            } catch (err) {
                                console.error('Error processing message:', err);
                            }
                        });

                        wsClient.current = client;
                    },
                    onWebSocketClose: () => {
                        console.log('WebSocket connection closed');
                        isConnectingRef.current = false;
                        wsClient.current = null;
                        subscriptionRef.current = null;
                        scheduleReconnect();
                    }
                });

                await client.activate();
            } catch (error) {
                console.error('Error during WebSocket connection:', error);
                isConnectingRef.current = false;
                scheduleReconnect();
            }
        };

        const scheduleReconnect = () => {
            if (reconnectTimeoutRef.current) {
                clearTimeout(reconnectTimeoutRef.current);
            }
            if (reconnectAttempts < maxReconnectAttempts) {
                reconnectAttempts++;
                const delay = baseReconnectDelay * Math.pow(2, reconnectAttempts);
                reconnectTimeoutRef.current = setTimeout(connectWebSocket, delay);
            }
        };

        connectWebSocket();

        return () => {
            cleanupWebSocket();
            const currentProcessedIds = new Set(processedMessageIds.current);
            processedMessageIds.current.clear();
            currentProcessedIds.clear();
            messageQueueRef.current.clear();
        };
    }, [selectedChatId, cleanupWebSocket, processMessage]);

    // Загрузка сообщений только при смене selectedChatId
    useEffect(() => {
        if (!selectedChatId) {
            setLocalMessages([]);
            setLoading(false);
            return;
        }

        const loadMessages = async () => {
            setLoading(true);
            try {
                const messages = await chatApi.getChatMessages(selectedChatId);
                setLocalMessages(messages || []);
                messages?.forEach(msg => processedMessageIds.current.add(msg.id));
            } catch (err) {
                setError('Failed to load messages: ' + (err instanceof Error ? err.message : 'Unknown error'));
                setLocalMessages([]);
            } finally {
                setLoading(false);
            }
        };

        loadMessages();
    }, [selectedChatId]);

    // Загрузка подключений
    useEffect(() => {
        if (!selectedChatId) return;

        const fetchConnections = async () => {
            try {
                const connections = await connectionApi.getConnectionsForChat(selectedChatId);
                setConnections(connections);
            } catch (err) {
                setError('Failed to load connections: ' + (err instanceof Error ? err.message : 'Unknown error'));
            }
        };

        fetchConnections();
    }, [selectedChatId]);

    // Отправка сообщения с немедленным отображением ответа LLM
    const handleSendMessage = useCallback(async () => {
        if (!message.trim() || !selectedChatId) return;

        const currentMessage = message.trim();
        setMessage('');
        setLoading(true);
        setError('');

        try {
            const tempMessage: Message = {
                id: `temp_${Date.now()}`,
                chatId: selectedChatId,
                content: currentMessage,
                fromUser: true,
                createdAt: new Date().toISOString()
            };
            setLocalMessages(prev => [...prev, tempMessage]);

            await chatApi.sendMessage(selectedChatId, currentMessage, true, selectedLLM);

            if (isSQLQuery(currentMessage)) {
                const response = await sqlApi.optimizeQuery({
                    chatId: selectedChatId,
                    query: currentMessage,
                    databaseConnectionId: connections.length > 0 ? connections[0].id : undefined,
                    llm: selectedLLM,
                });
                // Сразу добавляем ответ от LLM в чат
                const llmMessage: Message = {
                    id: `llm_${Date.now()}`,
                    chatId: selectedChatId,
                    content: response.optimizedQuery || 'Ошибка оптимизации',
                    fromUser: false,
                    createdAt: new Date().toISOString()
                };
                setLocalMessages(prev => {
                    const exists = prev.some(m => m.id === llmMessage.id);
                    if (exists) return prev;
                    return [...prev, llmMessage];
                });
            } else {
                const response: Message = {
                    id: `sys_${Date.now()}`,
                    chatId: selectedChatId,
                    content: "Пожалуйста, отправьте SQL запрос для оптимизации",
                    fromUser: false,
                    createdAt: new Date().toISOString()
                };
                await chatApi.sendMessage(selectedChatId, response.content, false);
                setLocalMessages(prev => {
                    const exists = prev.some(m => m.id === response.id);
                    if (exists) return prev;
                    return [...prev, response];
                });
            }
        } catch (err) {
            setError('Failed to send message: ' + (err instanceof Error ? err.message : 'Unknown error'));
            setLocalMessages(prev => prev.filter(msg => !msg.id.startsWith('temp_')));
        } finally {
            setLoading(false);
        }
    }, [message, selectedChatId, connections, selectedLLM, isSQLQuery]);

    const handleKeyDown = useCallback((e: React.KeyboardEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSendMessage();
        }
    }, [handleSendMessage]);

    // Оптимизированное рендеринг сообщений
    const renderedMessages = useMemo(() => {
        return localMessages.map((msg) => (
            <div
                key={msg.id}
                className={cn(
                    'p-3 rounded-lg max-w-[80%] break-words',
                    msg.fromUser ? 'bg-[#161616] text-text ml-auto' : 'bg-[#4A4A4A] text-text mr-auto'
                )}
            >
                {isSQLQuery(msg.content) ? (
                    <SyntaxHighlighter
                        language="sql"
                        style={vscDarkPlus}
                        customStyle={{ background: 'transparent', padding: 0, margin: 0, fontSize: '14px', whiteSpace: 'pre-wrap', wordBreak: 'break-all' }}
                    >
                        {msg.content}
                    </SyntaxHighlighter>
                ) : (
                    <p className="whitespace-pre-wrap">{msg.content}</p>
                )}
            </div>
        ));
    }, [localMessages, isSQLQuery]);

    return (
        <div className="flex-1 flex flex-col h-screen bg-background text-text">
            <div className="p-4">
                <div className="mb-4 flex justify-center">
                    <LLMSelect value={selectedLLM} onValueChange={onSelectLLM} />
                </div>
                <div className="flex-1 bg-secondary rounded-lg p-4 overflow-y-auto" style={{ height: 'calc(100vh - 260px)' }}>
                    {loading ? (
                        <p className="text-gray-500">Loading messages...</p>
                    ) : localMessages.length === 0 ? (
                        <p className="text-gray-500">No messages yet. Start the conversation!</p>
                    ) : (
                        <div className="flex flex-col space-y-4">
                            {renderedMessages}
                            <div ref={messagesEndRef} />
                        </div>
                    )}
                </div>
            </div>
            <div className="p-4 mt-auto">
                {error && <p className="text-red-500 text-sm mb-2">{error}</p>}
                <Button onClick={onConnectDB} className="mb-2" disabled={loading}>
                    Connect Database
                </Button>
                <div className="flex items-center space-x-2">
                    <button
                        onClick={() => setMppToggle(!mppToggle)}
                        className={cn('px-2 py-1 rounded-lg', mppToggle ? 'bg-primary' : 'bg-[#4A4A4A]')}
                        disabled={loading}
                    >
                        MPP
                    </button>
                    <Input
                        value={message}
                        onChange={(e) => setMessage(e.target.value)}
                        onKeyDown={handleKeyDown}
                        placeholder="Waiting for your SQL magic..."
                        className="flex-1 bg-[#4A4A4A] text-text"
                        multiline
                        disabled={loading}
                    />
                    <Button onClick={handleSendMessage} className="p-2 rounded-full" disabled={loading}>
                        ➤
                    </Button>
                </div>
            </div>
        </div>
    );
});

export default ChatArea;
