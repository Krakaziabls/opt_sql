import apiClient from './client';
import { Message } from './chat';

export interface SqlQueryRequest {
    chatId: string;
    query: string;
    databaseConnectionId?: string;
    llm: string;
}

export interface SqlQueryResponse {
    id: string;
    originalQuery: string;
    optimizedQuery: string;
    executionTimeMs?: number;
    createdAt: string;
    message: Message;
}

export const sqlApi = {
    optimizeQuery: async (request: SqlQueryRequest): Promise<SqlQueryResponse> => {
        console.log('Sending SQL optimization request:', request);
        const response = await apiClient.post('/sql/optimize', {
            chatId: request.chatId,
            query: request.query,
            databaseConnectionId: request.databaseConnectionId,
            llm: request.llm,
        });
        return { ...response.data, id: String(response.data.id) };
    },

    getQueryHistory: async (chatId: string): Promise<SqlQueryResponse[]> => {
        const response = await apiClient.get(`/sql/history/${chatId}`);
        return response.data.map((item: any) => ({ ...item, id: String(item.id) }));
    },
};
